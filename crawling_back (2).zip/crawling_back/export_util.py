import xlwt

CELL_WIDTH = 256 * 160
FONT_HEIGHT = 20 * 12
ALIGNMENT_VERT = 0x01

class ExportUtil:
  '导出类'


  def __init__(self, sheet_name, contents, filename):
    self.sheet_name = sheet_name
    self.contents = contents
    self.filename = filename

  # 导出Excel
  def export(self):
    wb = xlwt.Workbook()
    ws = wb.add_sheet(self.sheet_name)

    # title设置背景色颜色
    pattern = xlwt.Pattern()

    xlwt.add_palette_colour('custom_color', 0x21)
    wb.set_colour_RGB(0x21, 141, 154, 234)

    pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    site_style = xlwt.easyxf('pattern: pattern solid, fore_colour custom_color')

    # title设置对齐
    site_al = xlwt.Alignment()
    # title设置垂直居中
    site_al.vert = ALIGNMENT_VERT
    site_style.alignment = site_al

    # title设置字体
    site_font = xlwt.Font()
    # title设置字体加粗
    site_font.bold = True
    site_font.height = FONT_HEIGHT
    site_style.font = site_font

    # subtitle设置背景色
    subtitle_style = xlwt.XFStyle()
    subtitle_pattern = xlwt.Pattern()
    subtitle_pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    subtitle_pattern.pattern_fore_colour = xlwt.Style.colour_map['ice_blue']
    subtitle_style.pattern = subtitle_pattern

    # subtitle设置对齐
    subtitle_al = xlwt.Alignment()
    # subtitle设置垂直居中
    subtitle_al.vert = ALIGNMENT_VERT
    subtitle_style.alignment = subtitle_al

    # subtitle设置字体
    subtitle_font = xlwt.Font()
    # subtitle设置字体加粗
    subtitle_font.bold = True
    subtitle_font.height = FONT_HEIGHT
    subtitle_style.font = subtitle_font

    # content设置对齐
    content_style = xlwt.XFStyle()
    content_al = xlwt.Alignment()
    # content设置垂直居中
    content_al.vert = ALIGNMENT_VERT
    content_style.alignment = content_al

    # content设置字体
    content_font = xlwt.Font()
    content_font.height = FONT_HEIGHT
    content_style.font = content_font

    row_num = 0

    for title in self.contents:
      ws.write(row_num, 0, title, site_style)
      row_num += 1

      for sub_title in self.contents[title]:
        ws.write(row_num, 0, sub_title + '：', subtitle_style)
        row_num += 1

        links = self.contents[title][sub_title]
        if len(links) > 0:
          for link in links:
            ws.write(row_num, 0, xlwt.Formula('HYPERLINK("' + link[1] + '";"' + link[0] + '")'), content_style)
            row_num += 1

    # 设置单元格宽度
    ws.col(0).width = CELL_WIDTH

    wb.save(self.filename)