import win32com.client as win32

def send(filename):
  outlook = win32.Dispatch('outlook.application')
  mail = outlook.CreateItem(0)

  # 接受方信息
  # receivers = ['pv.china@bayer.com', 'medicalcompliance.china@bayer.com']
  receivers = ['735243141@qq.com']
  mail.To = ';'.join(receivers)

  # 抄送方信息
  # cc_list = ['meng.yu.ext@bayer.com', 'carl.zhang@bayer.com']
  cc_list = ['meng.yu.ext@bayer.com']
  mail.Cc = ';'.join(cc_list)

  # 构造附件
  mail.Attachments.Add(filename)

  # 邮件主题
  mail.Subject = 'Notice from National Products Administration'

  # 邮件正文内容
  mail.Body = 'Please check the attachment for new articles.'

  # 发送邮件
  mail.Send()