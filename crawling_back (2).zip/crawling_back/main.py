import export_util
import crawling_by_selenium
import time
import datetime
import json
import os
from selenium import webdriver
from selenium.webdriver.edge.service import Service
from webdriver_manager.microsoft import EdgeChromiumDriverManager
import send_email

print('=== start crawling at ', time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))

SLEEP_TIME = 15

# selenium
options = webdriver.EdgeOptions()
# options.use_chromium = True

# 隐藏浏览器
# options.add_argument('--headless')
options.add_argument('-enable-webgl --no-sandbox --disable-dev-shm-usage')
options.add_experimental_option('excludeSwitches', ['enable-automation'])
user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53'
options.add_argument(f'user-agent={user_agent}')
options.add_argument("--disable-3d-apis")

# 取消浏览器被自动控制字样
options.add_argument('--disable-blink-features=AutomationControlled')
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option('useAutomationExtension', False)

# browser = webdriver.Edge(service=Service(EdgeChromiumDriverManager().install()), options = options)
driver_path = 'C:\crawling_back\edgedriver_win64\msedgedriver.exe'
browser = webdriver.Edge(service=Service(driver_path), options = options)

# 公司浏览器会先默认打开Bayer网站，这里需要特殊处理，先开启浏览器，然后等待一段时间
# 同时，为打开浏览器所开的网页，涉及的日志可忽略
#browser.get('https://bayernet.int.bayer.com/')
#time.sleep(SLEEP_TIME)
#browser.implicitly_wait(SLEEP_TIME)

# 导入要爬取的网址
urls = json.load(open('urls.json', encoding='utf-8-sig'))

# 如果当前时间是周一，取前3天的更新；否则取前1天的更新
#if datetime.date.today().isoweekday() == 1:
#  date_before_days = 3
#else:
#  date_before_days = 1
date_before_days = 1

# 设置要爬取的日期
#if datetime.date.today().strftime("%Y-%m-%d") == '2023-07-03':
#   selected_date = ['2023-06-30']
#else:
#  selected_date = list(map(lambda i: (datetime.date.today() + datetime.timedelta(i-date_before_days)).strftime("%Y-%m-%d"), range(date_before_days)))
selected_date = list(map(lambda i: (datetime.date.today() + datetime.timedelta(i-date_before_days)).strftime("%Y-%m-%d"), range(date_before_days)))

file_copied = False

# 获取爬取内容
crawling = crawling_by_selenium.Crawling(SLEEP_TIME, browser, urls, selected_date)
contents = crawling.get_all_site_contents()

# 导出Excel
filename = f'notice-{time.strftime("%Y%m%d%H%M%S", time.localtime())}.xls'

upload_path = f'./python_notice/{filename}'

# Excel全路径
filename = f'{os.getcwd()}\\python_notice\\{filename}'
export_util.ExportUtil('sheet1', contents, filename).export()

# 关闭浏览器
browser.quit()

# upload to aws s3
if not file_copied:
  #os.system(f'aws s3 cp {upload_path} s3://py-crawling')
  file_copied = True

# delete files that are genereated 7 days ago
try:
  os.system("forfiles /p python_notice /s /m *.* /d -7 /c \"cmd /c del /f /q /a @path\"")
except:
  print("failed to delete files")

print("sending email...")

# 发送邮件
# send_email.send(filename)