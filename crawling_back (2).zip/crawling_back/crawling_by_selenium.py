from bs4 import BeautifulSoup
import time
import re
from retry import retry

class Crawling:
  '爬取类'


  def __init__(self, sleep_time, browser, urls, selected_date):
    self.sleep_time = sleep_time
    self.browser = browser
    self.urls = urls
    self.selected_date = selected_date


  # 1. 国家市场监督管理总局：总局文件，政策解读
  def samr(self):
    return self.notice_contents('samr', 'div.Three_zhnlist_02 ul', '', '', self.selected_date)

  # 2. 国家药品监督管理局：公告通告，征求意见，法规文件，政策解读，产品召回
  def nmpa(self):
    return self.notice_contents('nmpa', 'div.list ul li', 'https://www.nmpa.gov.cn/', '../', self.selected_date)

  # 3. 国家药品监督管理局药品评价中心 & 国家药品不良反应检测中心：通知通告，政策法规，安全警示
  def cdr_adr(self):
    site_result = {}
    site_entity = self.urls['cdr_adr']
    title = site_entity['title']
    site_result.update({title: {}})

    for sub_entity in site_entity['links']:
      sub_title = sub_entity['sub_title']
      url = sub_entity['link']

      print()
      print('  on webpage: ', sub_title)
      if url == 'https://www.cdr-adr.org.cn/tzgg_home/':
        url_result = self.content_by_url(url, 'td.divStyle', url, './', self.selected_date)
      else:
        url_result = self.content_by_url(url, 'td.showTd', 'https://www.cdr-adr.org.cn/', '../', self.selected_date)

      site_result[title].update({sub_title: url_result})

    return site_result

  # 4. 国家药品监督管理局药品评审中心：工作动态，法律法规，中心规章
  def cde(self):
    return self.notice_contents('cde', 'div.news_date', 'https://www.cde.org.cn', '', self.selected_date)

  # 5. 北京市市场监督管理局：通知，公示公告
  def scjgj(self):
    return self.notice_contents('scjgj', 'div.public_list_team ul li', None, './', self.selected_date)

  # 6. 北京市药品监督管理局：最新信息，政策截图
  def yjj_beijing(self):
    return self.notice_contents('yjj_beijing', 'p.xinwen', 'http://yjj.beijing.gov.cn/', '', self.selected_date)

  # 7. 上海市药品监督管理局：药品-最新公开信息，政策法规，曝光台 化妆品-最新公开信息，政策法规，曝光台 医疗器械-最新公开信息，政策法规，曝光台
  def yjj_sh(self):
    tmp_date = list(map(lambda d: d.replace('-', '.'), self.selected_date))
    return self.notice_contents('yjj_sh', 'ul.uli14 li', 'https://yjj.sh.gov.cn/', '', tmp_date)

  # 8. 广东省药品监督管理局：通知公告，工作文件，法规解读，消费警示，监管信息公开
  def mpa_gd(self):
    return self.notice_contents('mpa_gd', 'ul.infoList li h4', '', '', self.selected_date)

  # 9. 广东省药品不良反应监测中心：通知公告，政策法规
  def gdadr(self):
    return self.notice_contents('gdadr', 'ul.list1 li', '', '', self.selected_date)

  # 10. 江苏省药品监督管理局：药品-工作动态 医疗器械-工作动态 化妆品-工作动态
  def da_jiangsu(self):
    return self.notice_contents('da_jiangsu', 'div.default_pgContainer li', 'http://da.jiangsu.gov.cn', '', self.selected_date)

  # 11. 江苏省药品不良反应监测中心：药品-通知通告，法律文件，警戒快讯 医疗器械-通知通告，法规文件安全警示 化妆品-通知公告，法规文件，警戒快讯
  def jsadr(self):
    return self.notice_contents('jsadr', 'div.abse div.mt-10', None, '', self.selected_date)

  # 12. 云南省市场监督管理局：公示公告
  def amr_yn(self):
    return self.notice_contents('amr_yn', 'ul.news-list li', 'http://amr.yn.gov.cn/', '', self.selected_date)

  # 13. 云南省药品监督管理局：公示公告，通知通报，工作文件，重要政策解读，部门规章，法律行政法规，国家法律
  def mpa_yn(self):
    site_result = {}
    site_entity = self.urls['mpa_yn']
    title = site_entity['title']
    site_result.update({title: {}})

    for sub_entity in site_entity['links']:
      sub_title = sub_entity['sub_title']
      url = sub_entity['link']

      urls_by_ul = [
        'http://mpa.yn.gov.cn/newsite/ZwgkNewsList.aspx?CID=5e41048e-2e65-4d89-944f-79fb9c05b8dd',
        'http://mpa.yn.gov.cn/newsite/ZwgkNewsList.aspx?CID=C793B531-E2C2-4EC3-9EFE-A2FC5DDF7938',
      ]

      print()
      print('  on webpage: ', sub_title)

      if url in urls_by_ul:
        url_result = self.content_by_url(url, 'ul.zfxxgnewlist li', 'http://mpa.yn.gov.cn/newsite/', '', self.selected_date)
      else:
        url_result = self.content_by_url(url, 'div.listR ul.new02 li', 'http://mpa.yn.gov.cn/newsite/', '', self.selected_date)

      site_result[title].update({sub_title: url_result})

    return site_result

  # 14. 卫生健康委：政策法规
  def nhc(self):
    return self.notice_contents('nhc', 'ul.zxxx_list li', 'http://www.nhc.gov.cn', '', self.selected_date)

  # 15. 科学技术部：国家科技法律法规
  def most(self):
    return self.notice_contents('most', 'div.list-main ul li', 'http://www.most.gov.cn/', '../../', self.selected_date)

  # 单个网站所有网页的内容, pre_url为None时表示用网页当前的URL作为url前缀
  def notice_contents(self, site_key, select_string, pre_url, replace_string, selected_date):
    site_result = {}
    site_entity = self.urls[site_key]
    title = site_entity['title']
    site_result.update({title: {}})

    for sub_entity in site_entity['links']:
      sub_title = sub_entity['sub_title']

      print()
      print('  on webpage: ', sub_title)
      url = sub_entity['link']

      if pre_url == None:
        prefix_url = url
      else:
        prefix_url = pre_url

      url_result = self.content_by_url(url, select_string, prefix_url, replace_string, selected_date)
      
      
      site_result[title].update({sub_title: url_result})

    return site_result

  # 单个网页对应的内容
  def content_by_url(self, url, select_string, pre_url, replace_string, selected_date):
    url_result = []

    self.browser.get(url)
    #self.browser.navigate.to(url) 

    time.sleep(self.sleep_time)
    # self.browser.implicitly_wait(self.sleep_time)

    soup = BeautifulSoup(self.browser.page_source, 'lxml')
    els = soup.select(select_string)

    if len(els) == 0:
      return []

    for el in els:
      self.append_to_notice_urls(url_result, el, url, pre_url, replace_string, selected_date)

    return url_result

  def append_to_notice_urls(self, notice_urls, el, url, pre_url, replace_string, selected_date):
    date_seperated_urls = [
      'https://www.cde.org.cn/main/news/listpage/3cc45b396497b598341ce3af000490e5',
      'https://www.cde.org.cn/main/policy/listpage/9f9c74c73e0f8f56a8bfbc646055026d',
      'https://www.cde.org.cn/main/policy/listpage/369ac7cfeb67c6000c33f85e6f374044'
    ]

    if url in date_seperated_urls:
      spans = el.findChildren('span')
      year_and_month = spans[0].text.split('.')
      current_date_str = '-'.join([year_and_month[0], year_and_month[1], spans[1].text])

      if current_date_str in selected_date:
        children = el.findNextSibling().findChildren()
        title = children[0].text.strip()
        link = self.get_link_url(children[2].attrs['href'], pre_url, replace_string)
        title = self.title_with_date(title, current_date_str)
        notice_urls = self.append_title_and_link(notice_urls, title, link)
    else:
      if len(list(filter(lambda d: d in el.text, selected_date))) > 0:
        try:
          mat = re.search(r"(\d{4}-\d{1,2}-\d{1,2})", el.text)
          current_date_str = mat.group(0)
        except AttributeError:
          mat = re.search(r"(\d{4}.\d{1,2}.\d{1,2})", el.text)
          current_date_str = mat.group(0).replace('.', '-')

        a = self.get_link_element(url, el)
        link = self.get_link_url(a.attrs['href'], pre_url, replace_string)
        title = a.text.strip()
        title = self.title_with_date(title, current_date_str)

        notice_urls = self.append_title_and_link(notice_urls, title, link)

    return notice_urls

  # title超过60个字符时，缩略显示，同时在标题的后边显示日期
  def title_with_date(self, title, date_string):
    if len(title) > 60:
      text = title[0:57] + '...'
    else:
      text = title

    return text + '（' + date_string + '）'

  def append_title_and_link(self, notice_urls, title, link):
    print()
    print('    ', title)
    print('    ', link)

    notice_urls.append([title, link])

    return notice_urls

  # 超链接的href属性有可能是相对路径，这种情况下需要替换为绝对路径
  def get_link_url(self, href, pre_url, replace_string):
    href = href.replace(replace_string, '')

    if 'http' not in href:
      return pre_url + href
    else:
      return href

  # 超链接元素
  def get_link_element(self, url, el):
    if url in ['https://www.cdr-adr.org.cn/sy_zcfg/', 'https://www.cdr-adr.org.cn/sy_aqjs1/']:
      return el.findPreviousSibling().findChild('a')
    else:
      return el.findChild('a')

  # 获取所有网站的更新
  @retry(tries=5)
  def get_all_site_contents(self):
    result = {}

    for index in self.urls:
      title = self.urls[index]['title']

      print()
      print('start crawling site:', title)

      #contents = getattr(self, index)()
      try:
        contents = getattr(self, index)()
      except:
        pass

      if contents is None:
        print(f"{index} has no contents...")


      result.update(contents)

    return result